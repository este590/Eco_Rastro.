# ECO-RASTRO

Aplicación Android educativa para fomentar el reciclaje, el ahorro de agua y energía y los hábitos ambientales.

## Funciones
- Inicio con resumen de puntos ECO.
- Registro diario aproximado de agua, energía y residuos.
- Guía para separar papel/cartón, plásticos/metales, vidrio, orgánicos y no reciclables.
- Retos, puntos y niveles.
- Muro comunitario local.
- Icono de aplicación y logo ECO-RASTRO incluidos.

## Compilar
Requisitos: JDK 17, Android SDK 35 y Gradle 8.9.

```bash
gradle assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.

Los registros y publicaciones de esta versión se guardan localmente en el dispositivo. No hay cuentas ni sincronización en línea.
